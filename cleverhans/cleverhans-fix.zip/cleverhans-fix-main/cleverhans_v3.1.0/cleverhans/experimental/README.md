This directory contains experimental features of cleverhans, which are not
integrated into the main API yet.
