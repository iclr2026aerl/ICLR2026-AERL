# Defenses implemented with JAX
