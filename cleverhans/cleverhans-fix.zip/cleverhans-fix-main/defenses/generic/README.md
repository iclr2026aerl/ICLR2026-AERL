# Generic Defenses (framework independent)

This folder contains implementations of defenses (as standalone scripts) that 
are implemented in a framework independent way (for example, it uses the numpy 
library only or can handle support for all major deep learning libraries).
