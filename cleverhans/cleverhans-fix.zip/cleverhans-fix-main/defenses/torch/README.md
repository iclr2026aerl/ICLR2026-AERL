# Defenses implemented with PyTorch
