# Defenses implemented with TensorFlow 2
