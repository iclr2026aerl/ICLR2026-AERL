# Generic Code (framework independent)

This folder contains code that is framework independent (for example, it uses 
the numpy library only or can handle support for all major deep learning 
libraries).
