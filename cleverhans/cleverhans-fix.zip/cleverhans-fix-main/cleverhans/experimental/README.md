This directory contains experimental features of CleverHans, which are not
integrated into the main API yet.
